package com.example.assignmenttwo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class GamePlay {

    // Constants
    private static final int MAX_MATCHES = 12;

    // Fields
    private int totalGuesses;
    private int totalCorrect;
    private boolean isFirstGuess;
    private Card cardFirst;
    private Card cardSecond;
    private ArrayList<String> cardTypes;
    private ArrayList<Card> cards;
    private TextView textviewGuesses;
    private Context context;

    // Constructor
    public GamePlay(Context context) {
        this.context = context;
        setupGame();  // Initialize the game
    }
    public void setupGame() {
        // Initialize fields
        totalGuesses = 0;
        totalCorrect = 0;
        isFirstGuess = true;

        // Find the TextView for guesses
        textviewGuesses = ((Activity) context).findViewById(R.id.tv_num_guesses);

        // Initialize cards

        //make this more efficient
        cards = new ArrayList<>();

        // Create and shuffle card types
        cardTypes = new ArrayList<>();

        //create pictures that i will use in the cards
        ArrayList<String> cardPictures = new ArrayList<>(Arrays.asList(
                "artist",
                "astronaut",
                "coder",
                "doctor",
                "police",
                "scientist"
        ));

        // Double the list to create pairs
        for (String picture : cardPictures) {
            //create a pair of a single type of card as we will match them
            cardTypes.add(picture);
            cardTypes.add(picture);
        }

        // Shuffle the card types to randomize the card order
        Collections.shuffle(cardTypes);

        // Create card objects and assign front and back images
        for (int i = 0; i < MAX_MATCHES; i++) {
            String cardType = cardTypes.get(i);
            String cardBack = "img_card_back"; // Common back image
            String cardFront = "img_card_front_" + cardType; // Dynamic front image based on the card type

            // Create a new Card object
            Card card = new Card(i, cardType, cardBack, cardFront);

            // Add the card to the list
            cards.add(card);
        }


        // Set up ImageViews and attach click listeners
        setupImageviewsAndOnclicks();

        //flips all the cards face down if they are not
        displayCards();

    }
    public void setupImageviewsAndOnclicks() {
        for (int i = 0; i < MAX_MATCHES; i++) {
            //get the image ids and find the associated ImageView where it should go
            int resId = context.getResources().getIdentifier("iv_card_" + i, "id", context.getPackageName());
            ImageView imageView = ((Activity) context).findViewById(resId);
            if (imageView != null) {
                //create card object, and set the image on the face of the card
                final Card card = cards.get(i);
                card.setImageViewCard(imageView);

                // Set the tag of the ImageView to the cardNum, again
                imageView.setTag(card.getCardNum());

                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onclickCard(v);  // Handle card click
                    }
                });
            }
        }
    }
    public void displayCardFaceUp(Card card) {
        card.setFaceUp(true);
        // Retrieve the resource ID for the front image of the card
        int resId = context.getResources().getIdentifier(card.getCardFront(), "drawable", context.getPackageName());
        // Set the image resource to the ImageView
        card.getImageviewCard().setImageResource(resId);
    }
    public void displayCardFaceDown(Card card) {
        card.setFaceUp(false);
        // Retrieve the resource ID for the back image of the card
        int resId = context.getResources().getIdentifier(card.getCardBack(), "drawable", context.getPackageName());
        // Set the image resource to the ImageView
        card.getImageviewCard().setImageResource(resId);
    }

    public void displayCards() {
        // Loop through each card in the cards list and display it face down
        for (Card card : cards) {
            displayCardFaceDown(card);
        }
    }


    public void flipCard(Card card) {
        //flips the card to the opposite side
        if (card.isFaceUp()) {
            displayCardFaceDown(card);
        } else {
            displayCardFaceUp(card);
        }
    }

    public void onclickCard(View view) {
        // Disable card flipping while two cards are already selected, gives user a small delay so they cant spam flips
        if (cardFirst != null && cardSecond != null) {
            return;  // Do nothing if two cards are already flipped
        }

        int cardNum = (int) view.getTag();  // Get the cardNum from the clicked ImageView's tag
        Card clickedCard = getCardByCardNum(cardNum);  // Get the corresponding Card object

        if (clickedCard != null && !clickedCard.isFaceUp()) {
            flipCard(clickedCard);  // Flip the card up

            if (isFirstGuess) {
                cardFirst = clickedCard;  // Set the first card
                isFirstGuess = false;
            } else {
                cardSecond = clickedCard;  // Set the second card
                checkCardMatch();  // Check if the two cards match
                isFirstGuess = true;
                totalGuesses++;
                updateGuessesTextView();
            }
        }
    }
    public void checkCardMatch() {
        //logic to check if user has picked both cards, otherwise it will not check matches
        if (cardFirst != null && cardSecond != null) {
            if (cardFirst.getCardType().equals(cardSecond.getCardType())) {
                // Cards match, so disable them
                totalCorrect++;

                cardFirst.getImageviewCard().setEnabled(false);
                cardSecond.getImageviewCard().setEnabled(false);

                // Reset card selection
                cardFirst = null;
                cardSecond = null;

                // Check if the game is over
                if (totalCorrect == MAX_MATCHES / 2) {
                    gameOver();  // All matches found, game over
                }

            } else {
                // Cards don't match, flip them back after a delay
                final Card firstCard = cardFirst;
                final Card secondCard = cardSecond;

                // Delay flipping the cards back
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        displayCardFaceDown(firstCard);
                        displayCardFaceDown(secondCard);

                        // Reset card selection after flipping them back
                        cardFirst = null;
                        cardSecond = null;
                    }
                }, 1000);  // Delay of 1 second
            }
        }
    }

    public void gameOver() {
        //creates an intent and sends the total amount of guesses the user has made over to the PlayerActivity to use
        Intent intent = new Intent(context, PlayerActivity.class);
        intent.putExtra("totalGuesses", totalGuesses);
        context.startActivity(intent);
    }
    public Card getCardByCardNum(int cardNum){
        //iterates through all the cards until it finds the cardNum it is looking for then returns it
        for (Card card : cards) {
            if (card.getCardNum() ==  cardNum) {
                return card;
            }
        }
        return null;
    }
    public void updateGuessesTextView() {
        //sets the guesses textview to how many guesses the user has made
        textviewGuesses.setText("Guesses: " + totalGuesses);
    }
}

