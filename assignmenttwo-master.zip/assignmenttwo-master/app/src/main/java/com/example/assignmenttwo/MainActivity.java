package com.example.assignmenttwo;

import android.os.Bundle;
import android.view.View;
import android.content.Intent;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void onclickPlay(View view){
        //takes you to the game activity where you can flip cards
        Intent intent = new Intent(MainActivity.this, GameActivity.class);
        startActivity(intent);//starts the activity
    }
    public void onclickLeaderboard(View view){
        //takes you to the leaderboardactivity from the main menu
        Intent intent = new Intent(MainActivity.this, LeaderboardActivity.class);
        startActivity(intent);//starts the activity
    }
}