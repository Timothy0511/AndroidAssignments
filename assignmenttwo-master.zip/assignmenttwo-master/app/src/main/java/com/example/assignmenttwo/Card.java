package com.example.assignmenttwo;

import android.widget.ImageView;

public class Card {

    //properties cards will have when created
    private int cardNum;
    private String cardType;
    private String cardBack;
    private String cardFront;
    private ImageView imageviewCard;
    private boolean isFaceUp;

    // Constructor
    public Card(int cNum, String cType, String cBack, String cFront) {
        this.cardNum = cNum;
        this.cardType = cType;
        this.cardBack = cBack;
        this.cardFront = cFront;
        this.isFaceUp = false; // Cards start face down
    }

    // Getters and Setters
    // Returns card properties with the getters here
    public int getCardNum() { return cardNum; }
    public String getCardType() { return cardType; }
    public String getCardBack() { return cardBack; }
    public String getCardFront() { return cardFront; }
    public boolean isFaceUp() { return isFaceUp; }

    // changes card properties
    public void setFaceUp(boolean faceUp) {
        this.isFaceUp = faceUp;
    }

    //return the imageviewcard property
    public ImageView getImageviewCard() {
        return imageviewCard;
    }

    //changes the imageview property
    public void setImageViewCard(ImageView imageviewCard) {
        this.imageviewCard = imageviewCard;
    }
}
