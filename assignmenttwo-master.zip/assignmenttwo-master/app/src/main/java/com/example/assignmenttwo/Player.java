package com.example.assignmenttwo;

import android.content.Context;
import android.graphics.drawable.Drawable;

import androidx.core.content.res.ResourcesCompat;

public class Player {

    //stored player properties
    private String playerName;
    private Drawable playerAvatar;
    private int playerScore;

    // Constructor
    public Player(Context context, String name, int avatarID, int score) {
        this.playerName = name;
        this.playerAvatar = ResourcesCompat.getDrawable(context.getResources(), avatarID, null);
        this.playerScore = score;
    }

    // Getters
    //returns the player details if requested
    public String getPlayerName() {
        return playerName;
    }

    public Drawable getPlayerAvatar() {
        return playerAvatar;
    }

    public int getPlayerScore() {
        return playerScore;
    }
}