package com.example.assignmenttwo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PlayerActivity extends AppCompatActivity {

    //fields
    private int avatarID;  // This will be set based on user selection
    private String playerName;
    private int playerScore;
    private Intent intent;
    private Leaderboard leaderboardInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_player);

        // Initialize Leaderboard instance
        leaderboardInstance = Leaderboard.getInstance();  // Get the singleton instance

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Retrieve the data passed from GamePlay
        this.playerScore = getIntent().getIntExtra("totalGuesses", 0);

        TextView scoreView = findViewById(R.id.tv_playerscore);
        scoreView.setText("Your Score was: " + playerScore);
    }


    public void onclickSubmit(View view) {
        // get the player name from the edit text
        EditText nameEditText = findViewById(R.id.et_playername);
        playerName = nameEditText.getText().toString();

        // Get selected avatar from RadioGroup
        RadioGroup avatarGroup = findViewById(R.id.rg_avatar);
        int selectedId = avatarGroup.getCheckedRadioButtonId();

        // Check if the player name is entered
        if (TextUtils.isEmpty(playerName)) {
            // Show an error message or a Toast if the name is empty
            nameEditText.setError("Please enter your name");
            return;
        }

        // check if a radio button has been selected
        if (selectedId != -1) {
            // Find the selected RadioButton
            RadioButton selectedButton = findViewById(selectedId);
            // get the tag of selected radio button to determine which button the user selected
            String selectedTag = (String) selectedButton.getTag();

            // Convert the tag to an integer
            int avatarIndex = Integer.parseInt(selectedTag);
            avatarID = leaderboardInstance.getImageArray()[avatarIndex];

            // Create the Player object and update the leaderboard
            Player player = new Player(getApplicationContext(), playerName, avatarID, Integer.valueOf(playerScore));
            leaderboardInstance.updateLeaderboard(player);

            // Start the next activity
            intent = new Intent(PlayerActivity.this, LeaderboardActivity.class);
            startActivity(intent);
        } else {
            // Handle case where no avatar is selected
            Toast.makeText(this, "Please select an avatar", Toast.LENGTH_SHORT).show();
        }
    }

}
