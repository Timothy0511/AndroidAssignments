package com.example.assignmenttwo;

import android.content.Context;

import android.app.Activity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Comparator;

public class Leaderboard {
    //array to store the avatar images
    private static final int[] IMG_ARRAY = {
            R.drawable.img_card_front_coder,
            R.drawable.img_card_front_artist,
            R.drawable.img_card_front_astronaut,
            R.drawable.img_card_front_doctor,
            R.drawable.img_card_front_scientist
    };

    //variables
    private ArrayList<Player> leaderboard;
    private static Leaderboard leaderboardInstance;

    private Leaderboard(){
        leaderboard = new ArrayList<>();  // Initialize the leaderboard list
    }
    public static Leaderboard getInstance() {
        //creates an instance of leaderboard, otherwise returns an existing one
        if (leaderboardInstance == null) {
            leaderboardInstance = new Leaderboard();
        }
        return leaderboardInstance;
    }
    //return the Image array for the player icons
    public static int[] getImageArray() {
        return IMG_ARRAY;
    }

    public void updateLeaderboard(Player currentPlayer) {

        //adds players into the leaderboard list of max 5 players
        final int MAX_PLAYERS = 5;
        leaderboard.add(currentPlayer);

        //sorts the leaderboard in score order
        leaderboard.sort(Comparator.comparingInt(Player::getPlayerScore));

        //if there are too many players, which cannot fit on the leaderboard the one with the highest score is kicked off
        if (leaderboard.size() > MAX_PLAYERS) {
            leaderboard.remove(leaderboard.size() - 1);
        }

    }
    public void displayLeaderboard(Context context) {
        if (leaderboard == null || leaderboard.isEmpty()) {
            //if no one has added a leaderboard entry it will say no players, saying that it is intended for this to be empty
            Toast.makeText(context, "No players!?", Toast.LENGTH_SHORT).show();
        } else {
            //iterates through all the leaderboard positions to see if it should update it
            for (int i = 1; i <= leaderboard.size(); i++) {
                //gets current player index
                Player player = leaderboard.get(i - 1); // Adjust to match array indexing (0-based)

                //get the identifiers for the locations where we will put the user's score
                int picId = context.getResources().getIdentifier("iv_leaderboard_avatar" + i, "id", context.getPackageName());
                int nameId = context.getResources().getIdentifier("tv_leaderboard_name" + i, "id", context.getPackageName());
                int scoreId = context.getResources().getIdentifier("tv_leaderboard_score" + i, "id", context.getPackageName());

                //create the variables, where we can modify the LeaderboardActivity to show up with the player's scores
                ImageView imageView = ((Activity) context).findViewById(picId);
                TextView nameText = ((Activity) context).findViewById(nameId);
                TextView scoreText = ((Activity) context).findViewById(scoreId);

                // Update the UI with leaderboard data
                if (player != null) {
                    imageView.setImageDrawable(player.getPlayerAvatar());
                    nameText.setText(player.getPlayerName());
                    scoreText.setText(String.valueOf(player.getPlayerScore()));
                }
            }

        }
    }
}
