package com.example.assignmenttwo;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;



public class GameActivity extends AppCompatActivity {
    private GamePlay gamePlay;

    //will start the game when this method is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        gamePlay = new GamePlay(this);
        startGame();
    }

    //start game on creation
    public void startGame() {
        gamePlay.setupGame();
    }
}
