package com.example.assignmentone;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;

import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail);

        // Gets the Ids of the items inside the activity so they can be modifiied
        ImageView backgroundImage = findViewById(R.id.overlayImage);
        TextView titleText = findViewById(R.id.titleText);
        TextView contentText = findViewById(R.id.contentText);

        // Fetch the arrays from values folder
        String[] banners = getResources().getStringArray(R.array.string_array_banners);
        String[] titles = getResources().getStringArray(R.array.string_array_titles);
        String[] contents = getResources().getStringArray(R.array.string_array_content);

        // Assume we want to display the first item for demonstration purposes
        int index = getIntent().getIntExtra("INDEX", 0); // Default to 0 if no index is found


        // Get the drawable resource ID from the string array
        int resId = getResources().getIdentifier(banners[index], "drawable", getPackageName());

        // Set the image resource to the ImageView
        backgroundImage.setImageResource(resId);

        // Set the text to the TextViews
        titleText.setText(titles[index]);
        contentText.setText(contents[index]);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}