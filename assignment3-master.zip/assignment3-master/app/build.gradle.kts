import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.assignment3"
    compileSdk = 34


    defaultConfig {
        applicationId = "com.example.assignment3"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {


    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    testImplementation(libs.junit.jupiter)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    // Maps SDK for Android
    implementation(libs.play.services.maps)
    implementation(libs.play.services.location)
    // Told me to use above lines instead of bottom lines which was on the documentation
    //implementation("com.google.android.gms:play-services-maps:19.0.0")
    //implementation("com.google.android.gms:play-services-location:19.0.0")
    implementation(libs.places)
    //Use above instead of:
    //implementation("com.google.android.libraries.places:places:4.0.0")
    implementation(libs.volley)
    //use above instead of:
    // implementation("com.android.volley:volley:1.2.1")
    //implementation(libs.json) //this dont work but bottom line works idk
    implementation("org.json:json:20210307")
    //testing to se if working from home again to correct branch

}