package com.example.assignment3;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
//import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.android.volley.Cache;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class mapMock {
    private LatLng latlng;
    private GoogleMap myMap;




    private double lat;
    private double lng;

    private List<Charger> chargerList = new ArrayList<>();



    private Context context;
    /*
    this original version of this method returned a String request
    and used volley, because volley requires context this version inputs values based off of actual
    information of a charging station in hamilton
     */
    public String getStringRequestMock(String baseurl, double lati, double longi) {
        String queryURL = baseurl + "&latitude=" + lati + "&longitude=" + longi + "&key=" + "c725d7d8-ba73-4105-a090-304a6fba1211";


        String latitude = "-37.78813326176806";
        String longitude = "175.2582393340524";
        String name = "Hikotron at Hamilton Electric Vehicles";

        String address1 = "19 Massey Road";
        String address2 = "Frankton";
        String town = "Hamilton";
        String AccessComments = null;
        String generalComments = "2 x 7kW AC Type 2 sockets (user provided cable system)  Download the Hikotron mobile app to start charging session Monitor your charging session on the mobile app View live status of the charging posts at www.hikotron.com/map";
        String wholeAddress = address1 + "'" + address2 + "'" + town; //string builder, following if statements remove null values for a normal looking address
        String points = "2";
        String cost = "$0.50/kWh(min $2 fee)";

        String returnData = name + ":" + longitude + ":" + latitude + ":" + wholeAddress + ":" + generalComments + ":" + points + ":" + cost;
        return returnData;

    }

/*
used to create a request to get the location of an ev charger based off of a LatLng
in this version the passed vavlue isn't actually used
 */

  public String getEVLocations(LatLng latlng) {
        double latitude = latlng.latitude;
        double longitude = latlng.longitude;

        String baseurl = "https://api.openchargemap.io/v3/poi/?output=json&maxresults=10&includecomments=true";
       String stringRequest =getStringRequestMock(baseurl, latitude, longitude);


        return stringRequest;

    }
    /*
    this method is never actually used
     */
    public @NonNull String getFullAddress(String address1, String address2, String town) {
        String wholeAddress = "";

        if (address1 != null && !address1.equals("null") && !address1.isEmpty()) {
            wholeAddress = address1;
        }

        if (address2 != null && !address2.equals("null") && !address2.isEmpty()) {
            if (!wholeAddress.isEmpty()) {
                wholeAddress += ", ";
            }
            wholeAddress += address2;
        }

        if (town != null && !town.equals("null") && !town.isEmpty()) {
            if (!wholeAddress.isEmpty()) {
                wholeAddress += ", ";
            }
            wholeAddress += town;
        }

        return wholeAddress;
    }
    /*
    also not used
     */
    public void createEVMarkers(Charger charger) {
        // Create a new marker options object for the current charger

        // Check if the list already has 10 chargers
        if (chargerList.size() >= 10) {
            // Remove the oldest charger (index 0)
            chargerList.remove(0);

        }

        chargerList.add(charger);

        LatLng chargerLocation = new LatLng(charger.getLatitude(), charger.getLongitude());

        MarkerOptions markerOptions = new MarkerOptions()
                .position(chargerLocation)
                .title(charger.getName())
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.img_marker_ev)); // Use the EV marker icon

        // Add the marker to the map
        Marker marker = myMap.addMarker(markerOptions);

        // Associate the marker with the corresponding Charger object using setTag
        if (marker != null) {
            marker.setTag(charger); //why did you cast marker to Marker here lol
        }
    }

/*
 a stub to send a response as a string to simulate clicking the button
 */
    public String onMarkerClickStub(@NonNull markerMock marker) { //for some reason must be static
        // Retrieve the Charger object associated with the marker
        Charger charger = marker.getCharge();

        if (charger != null) {
         return charger.getName() + " " + charger.getLatitude() + " " + charger.getLongitude() + " "  + charger.getDescription().toString() + " " +  charger.getAddress();
        }
          return "error";
        // Return false to allow default behavior (e.g., moving the camera to the marker)
       // return false;
    }


/*
a stub to simulate the permision asking
 */
    public boolean onRequestPermissionsResultStub(Boolean permissionGranted) { //int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults
        // super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //if (requestCode == 1) {
        if (permissionGranted == true) { //grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
            //getLastLocation();
            return true;
        } else {
           // Toast.makeText(this, "Location permission is denied, pls allow permission or else", Toast.LENGTH_SHORT).show();
            System.out.println("permission denied");
            return false;

        }
        //}
    }

}





