package com.example.assignment3;

public class locationMock {
    public double mockLong;
    public double mockLat;

    public locationMock(double longi, double lati) {
        mockLong = longi;
        mockLat = lati;
    }

    public void setLongitude(double longitude) {
        mockLong = longitude;
    }

    public void setLatitude(double latitude) {
        mockLat = latitude;
    }

    public double getLongitude() {
       return mockLong;
    }

    public double getLatitude() {
       return mockLat;
    }

}
