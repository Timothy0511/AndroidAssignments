package com.example.assignment3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import androidx.annotation.DisplayContext;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

public class jUnitCharger {

   // private Charger charger;
    String name = "test";
    double longi = 30.5;//long and lat are random values
    double lati = 30.5;
    StringBuilder disc = new StringBuilder();

    String addr = "123 TotalyReal street";
    String points;
    String cost;

    Charger charger = new Charger(name, longi, lati, disc, addr, points, cost);

    @Before
    @DisplayName("if tests pass they are not null")
    public void setUp() {
        disc.append("example text");
    }

    @Test
    @DisplayName("test for if name null")
    public void nameCorrect() {
      assertEquals(charger.getName(), name);
    }
    @Test
    @DisplayName("testing if longitude is null")
    public void longitudeCorrect() {
        assertEquals(charger.getLongitude(), longi, 0.5);
    }
    @Test
    @DisplayName("is latitude null")
    public void latitudeCorrect() {
        assertEquals(charger.getLatitude(), lati, 0.5);
    }
    @Test
    @DisplayName("checking if the description is not null")
    public void discNotNull() {
        assertNotNull(charger.getDescription());
    }
    @Test
    @DisplayName("testing if the address is not null")
    public void addressNotNull() {
       assertEquals(charger.getAddress(), addr);
    }
   @Test
   @DisplayName("testing if the points is not null")
   public void pointsNotNull() {
  assertEquals(charger.getPoints(), points);
 }

   @Test
   @DisplayName("testing if the cost is not null")
   public void costNotNull() {
  assertEquals(charger.getCost(), cost);
 }



}
