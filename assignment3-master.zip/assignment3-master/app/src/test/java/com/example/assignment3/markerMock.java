package com.example.assignment3;

public class markerMock {
    private double markerLat;
    private double markerLng;
    private Charger charger;

    public markerMock(double lat, double lng, Charger chag) {
        markerLat = lat;
        markerLng = lng;
        charger = chag;
    }
/*
these methods are just sets and gets
 */
    public double getLatitude() {
        return markerLat;
    }

    public void setLatitude(double in) {
       markerLat = in;
    }

    public double getLong() {
      return  markerLng;
    }

    public void setLong(double in) {
        markerLng = in;
    }

    public Charger getCharge() {
       return charger;
    }

}
