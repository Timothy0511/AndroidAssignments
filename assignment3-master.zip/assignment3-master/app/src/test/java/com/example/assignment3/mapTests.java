package com.example.assignment3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


import androidx.annotation.NonNull;

import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class mapTests {
    private LatLng latlng;
    private GoogleMap myMap;
    private locationMock loc = new locationMock( 0, 0);;
    private double lat;
    private double lng;

    private String points = "2";
    private String cost = "$0.50";

    private List<Charger> chargerList = new ArrayList<>();
    private List<markerMock> markerList = new ArrayList<>();
    private List<String> namesList = new ArrayList<>();
    private String addr = "123TotalyRealStreet";

    private StringBuilder disc = new StringBuilder();

    private mapMock mock = new mapMock();//to reference the mock class without requiring static methods



   public void chargerMaker() {
       namesList.add("abc");
       namesList.add("def");
       namesList.add("ghi");
       namesList.add("jkl");
       namesList.add("mno");
       namesList.add("pqr");
       namesList.add("stu");
       namesList.add("vwx");
       namesList.add("yza");
       namesList.add("cba");


       for(int i = 0; i < 10; i++) {
           Charger charger = new Charger(namesList.get(i),lat + i, lng + i, disc, addr, points, cost);
           chargerList.add(charger);
           addMarker(charger);
       }
   }


    public void evMarkerGen(locationMock location) {

        if(chargerList.size() >= 10) {
            chargerList.remove(0);
        }
        Charger charger = new Charger("name",lat, lng, disc, addr, points, cost);
        chargerList.add(charger);
        //if like actual method this would add markers to the map
        addMarker(charger);
    }

    public void addMarker(Charger charger) {
       markerMock mark = new markerMock(charger.getLatitude(), charger.getLongitude(), charger);
       markerList.add(mark);
    }




    public void dummyMapLoader(@NonNull GoogleMap googleMap) {

        //Initialize map ready
        myMap = googleMap;
        lat = loc.getLatitude(); //initalise these values to show ev stations for current locations
        lng = loc.getLongitude();

        evMarkerGen(loc);


    }


    @Before
    public void setUp() {

        latlng = new LatLng(30.5, 30.5);
        disc.append("example");
        chargerMaker();

       // GoogleMap googleMap;
    }
    /*
    this is the test for if the map object is created correctly
     */
    @Test
    public void mapLoads() {

        dummyMapLoader(myMap);
        Charger cha = chargerList.get(0);
        assertNotNull(cha);
        double markerLong = markerList.get(0).getLong();
        double markerLat = markerList.get(0).getLatitude();
        assertEquals(markerLong, 0, 0.1);//first charger/marker is created at 0 0
        assertEquals(markerLat, 0, 0.1);

    }




   /*
   these tests for the onclick were made seperate to make debuging easier
    */
   //these tests are a set, it's effectivly one test
    @Test
    public void onclickTest() {
       String out = mock.onMarkerClickStub(markerList.get(0));
       assertNotNull(out);
    }
    @Test
    public void onclickTestName() {
        String out = mock.onMarkerClickStub(markerList.get(0));
        String[] resp = out.split(" ");
        assertEquals(resp[0], "abc");
    }
    @Test
    public void onclickTestLatitude() {
        String out = mock.onMarkerClickStub(markerList.get(0));
        String[] resp = out.split(" ");
        assertEquals(resp[1], "0.0");
    }
    @Test
    public void onclickTestLongitude() {
        String out = mock.onMarkerClickStub(markerList.get(0));
        String[] resp = out.split(" ");
        assertEquals(resp[2], "0.0");
    }
    @Test
    public void onclickTestDisc() {
        String out = mock.onMarkerClickStub(markerList.get(0));
        String[] resp = out.split(" ");
        assertEquals(resp[3], "example");
    }
    @Test
    public void onclickTestAddress() {
        String out = mock.onMarkerClickStub(markerList.get(0));
        String[] resp = out.split(" ");
        assertEquals(resp[4], "123TotalyRealStreet");
    }




    /*
       this test tests if the response for a request is returning a string in the correct format
    */
    @Test
    public void stringRequestTest() {

       latlng = new LatLng(markerList.get(0).getLatitude(), markerList.get(0).getLong());
       String req = mock.getEVLocations(latlng);
       String[] PlaceResponse = req.split(":");
       String[] adrressArray = PlaceResponse[3].split("'");
       assertEquals(PlaceResponse[0], "Hikotron at Hamilton Electric Vehicles");
       assertEquals(PlaceResponse[1], "175.2582393340524");
       assertEquals(PlaceResponse[2], "-37.78813326176806");
       assertEquals(adrressArray[0], "19 Massey Road");
       assertEquals(adrressArray[1], "Frankton");
       assertEquals(adrressArray[2], "Hamilton");
       String genComment = "2 x 7kW AC Type 2 sockets (user provided cable system)  Download the Hikotron mobile app to start charging session Monitor your charging session on the mobile app View live status of the charging posts at www.hikotron.com/map";
       assertEquals(PlaceResponse[4], genComment);
       assertEquals(PlaceResponse[5], "2");
       assertEquals(PlaceResponse[6], "$0.50/kWh(min $2 fee)");

    }





/*
these test for when permission to get user location for accepting and declining it
 */
    @Test
    public void getLocationDenied() {
       boolean response = mock.onRequestPermissionsResultStub(false);
       assertEquals(response, false);
    }
    @Test
    public void getLocationAccepted() {
        boolean response = mock.onRequestPermissionsResultStub(true);
        assertEquals(response, true);
    }



}
