package com.example.assignment3;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private GoogleMap myMap;
    public Location currentLocation;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private LatLng whereImAt;
    private double currentLat;
    private double currentLng;
    private String apiKey = "c725d7d8-ba73-4105-a090-304a6fba1211"; // api key for charge maps, i know its not secure here
    private List<Charger> chargerList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_map);
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyDvOghyeEGi2x2tQ16hptN5V6FA9rMrrLU");
        }
        AutocompleteSupportFragment autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);

        if (autocompleteFragment != null) {
            autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));
            autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(@NonNull Place place) {
                    LatLng searchedlatlng = place.getLatLng();
                    if (searchedlatlng != null) {
                        myMap.clear(); //clears map so no duplicate searched markers

                        // Move the map camera to the selected place
                        markCurrentLocation(myMap);
                        currentLat = searchedlatlng.latitude;
                        currentLng = searchedlatlng.longitude;
                        getEVLocations(searchedlatlng);
                        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(searchedlatlng, 15));
                        MarkerOptions marker = new MarkerOptions().position(searchedlatlng).title(place.getName());

                        // Changing marker icon
                        marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.img_marker_location_searched));

                        // adding marker
                        myMap.addMarker(marker);
                    }
                }

                @Override
                public void onError(@NonNull Status status) {
                    Log.i(TAG, "An error occurred: " + status);
                }
            });
        } else {
            Log.e(TAG, "Autocomplete fragment is null.");
        }

        //Initialise this variable
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        getLastLocation();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.MapActivity), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }

    /*
    Method to mark current location, implemented so that when map clears you can call this method
    to re-add the current location marker
     */
    private void markCurrentLocation(GoogleMap googleMap) {
        //add latitude and longitude
        whereImAt = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());

        MarkerOptions marker = new MarkerOptions().position(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude())).title("Current location");

        // Changing marker icon
        marker.icon(BitmapDescriptorFactory.fromResource(R.drawable.img_marker_location_current));

        // adding marker
        googleMap.addMarker(marker);

    }

    private void getEVLocations(LatLng latlng) {
        double latitude = latlng.latitude;
        double longitude = latlng.longitude;
        final String[] requestGot = new String[1];
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String baseurl = "https://api.openchargemap.io/v3/poi/?output=json&maxresults=10&includecomments=true";
        StringRequest stringRequest = getStringRequest(baseurl, requestGot);
        // Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

    private @NonNull StringRequest getStringRequest(String baseurl, String[] requestGot) {
        String queryURL = baseurl + "&latitude=" + currentLat + "&longitude=" + currentLng + "&key=" + apiKey;
        Log.d("location", queryURL);
        //String queryURL = "https://api.openchargemap.io/v3/poi/?output=json&countrycode=NZ&maxresults=10&includecomments=true&latitude=-37.78673576982036&longitude=175.31808769441312&key=c725d7d8-ba73-4105-a090-304a6fba1211";
        //queryURL above for easy testing it is currently location of UoW

        StringRequest stringRequest = new StringRequest(Request.Method.GET, queryURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        requestGot[0] = response;
                        // Parse the JSON response
                        try {
                            JSONArray jsonArray = new JSONArray(response);

                            //Iterate through the all the json entries
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject station = jsonArray.getJSONObject(i);

                                // Extract AddressInfo object
                                JSONObject addressInfo = station.getJSONObject("AddressInfo");

                                // Get Latitude, Longitude, and Name (Title)
                                double latitude = addressInfo.getDouble("Latitude");
                                double longitude = addressInfo.getDouble("Longitude");
                                String name = addressInfo.getString("Title");
                                Log.d("EV Station Name", name);
                                String address1 = addressInfo.getString("AddressLine1");
                                String address2 = addressInfo.getString("AddressLine2");
                                String town = addressInfo.getString("Town");
                                String AccessComments = addressInfo.getString("AccessComments");
                                String generalComments = station.optString("GeneralComments", "");
                                String wholeAddress = getFullAddress(address1, address2, town); //string builder, following if statements remove null values for a normal looking address
                                StringBuilder wholeComments = new StringBuilder();
                                String numPoints = station.optString("NumberOfPoints", "");
                                if (numPoints.equals("null") || numPoints.isEmpty()) { //sometimes locations will have null value for number of points
                                    numPoints = "N/A";
                                }
                                String cost = station.optString("UsageCost", "");
                                if (cost.equals("null") || cost.isEmpty()) { //sometimes locations will have null value for cost
                                    cost = "N/A";
                                }
                                //removes any null values from the description
                                if (!AccessComments.equals("null") && !AccessComments.isEmpty()) {
                                    wholeComments.append("").append(AccessComments).append(". ");
                                }

                                if (!generalComments.equals("null") && !generalComments.isEmpty()) {
                                    wholeComments.append(", ").append(generalComments).append(". ");
                                }
                                // If no comments are available, return a default message
                                if (wholeComments.length() == 0) {
                                    wholeComments.append("This station has no description");
                                }

                                //need to use another api to get the images for the charger objects before we can create them.
                                //create the the charger objects.

                               // String icon = "img_marker_ev.png";// make api retrieve a string

                                Charger charger = new Charger(name, longitude, latitude, wholeComments, wholeAddress, numPoints, cost);
                                createEVMarkers(charger);

                                Log.i("EV Station", "Name: " + name + ", Lat: " + latitude + ", Lng: " + longitude + ", Address: " + wholeAddress);
                                Log.i("Comments", "Comments: " + wholeComments);
                            }
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }

                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("VolleyError", "Error occurred: " + error.getMessage());
            }
        });
        return stringRequest;
    }
    //This method essentially the same as the comment if statements where it removes the null values of the
    //three elements and returns the remaining non null values
    private @NonNull String getFullAddress(String address1, String address2, String town) {
        String wholeAddress = "";

        if (address1 != null && !address1.equals("null") && !address1.isEmpty()) {
            wholeAddress = address1;
        }

        if (address2 != null && !address2.equals("null") && !address2.isEmpty()) {
            if (!wholeAddress.isEmpty()) {
                wholeAddress += ", ";
            }
            wholeAddress += address2;
        }

        if (town != null && !town.equals("null") && !town.isEmpty()) {
            if (!wholeAddress.isEmpty()) {
                wholeAddress += ", ";
            }
            wholeAddress += town;
        }

        return wholeAddress;
    }


    //Method to get current location
    private void getLastLocation() {
        //ASKS FOR PERMISSION WHEN TRYING TO GET CURRENT LOCATION
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //Specifically asks for fine location permission
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        //if permission granted then assign the currentlocation to the location that we go
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    currentLocation = location;

                    //find and store mapFragment into variable
                    SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
                    if (mapFragment != null) { //handles when the map fragment is null
                        mapFragment.getMapAsync(MapActivity.this);
                    } else {
                        Log.e("MapActivity", "Error: mapFragment is null");
                    }
                }
            }
        });
    }

    @Override //loads map when map is ready
    public void onMapReady(@NonNull GoogleMap googleMap) {

        //Initialize map ready
        myMap = googleMap;

        myMap.setOnMarkerClickListener(this);
        currentLat = currentLocation.getLatitude(); //initalise these values to show ev stations for current locations
        currentLng = currentLocation.getLongitude();
        markCurrentLocation(myMap);
        getEVLocations(whereImAt);

        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(whereImAt, 10)); //moves camera to current location at start and also zooms
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            } else {
                Toast.makeText(this, "Location permission is denied, pls allow permission or else", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void createEVMarkers(Charger charger) {
        // Create a new marker options object for the current charger

        // Check if the list already has 10 chargers
        if (chargerList.size() >= 10) {
            // Remove the oldest charger (index 0)
            chargerList.remove(0);

        }

        chargerList.add(charger);

        LatLng chargerLocation = new LatLng(charger.getLatitude(), charger.getLongitude());

        MarkerOptions markerOptions = new MarkerOptions()
                .position(chargerLocation)
                .title(charger.getName())
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.img_marker_ev)); // Use the EV marker icon

        // Add the marker to the map
        Marker marker = myMap.addMarker(markerOptions);

        // Associate the marker with the corresponding Charger object using setTag
        if (marker != null) {
            marker.setTag(charger); //why did you cast marker to Marker here lol
        }
    }
    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
        // Retrieve the Charger object associated with the marker
        Charger charger = (Charger) marker.getTag();

        if (charger != null) {
            // Open a new activity with charger details
            Intent intent = new Intent(MapActivity.this, ChargerActivity.class);
            intent.putExtra("charger_name", charger.getName());
            intent.putExtra("charger_lat", charger.getLatitude());
            intent.putExtra("charger_lng", charger.getLongitude());
            intent.putExtra("charger_comments", charger.getDescription().toString()); // Pass the full comments
            intent.putExtra("charger_points", charger.getPoints());
            intent.putExtra("charger_address", charger.getAddress());
            intent.putExtra("charger_cost", charger.getCost());
            startActivity(intent);
        }

        // Return false to allow default behavior (e.g., moving the camera to the marker)
        return false;
    }


}