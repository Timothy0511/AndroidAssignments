package com.example.assignment3;

import android.media.audiofx.AudioEffect;
import android.widget.ImageView;

public class Charger {
    private String name;
    private Double longitude;
    private Double latitude;
    private StringBuilder description;
    private String address;
    private String points;
    private String cost;


    //constructor
    public Charger(String name, Double longitude, Double latitude, StringBuilder description, String address,
                   String points, String cost) {
        this.name = name;
        this.longitude = longitude;
        this.latitude = latitude;
        this.description = description;
        this.address = address;
        this.points = points;
        this.cost = cost;

    }

    //getters
    public String getName(){
        return name;
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public StringBuilder getDescription() {
        return description;
    }

    public String getAddress() {return address; }

    public String getPoints() {return points;}

    public String getCost() {return cost;}



}
