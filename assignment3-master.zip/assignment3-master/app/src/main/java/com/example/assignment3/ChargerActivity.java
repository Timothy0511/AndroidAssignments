package com.example.assignment3;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

public class ChargerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_charger_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.ChargerActivity), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Receives intent that was passed from  the map activity and stores in variables, converts to string when needed
        String title = getIntent().getStringExtra("charger_name");
        double latitude = getIntent().getDoubleExtra("charger_lat", 0.0);
        String latitudeStr = String.valueOf(latitude);
        double longitude = getIntent().getDoubleExtra("charger_lng", 0.0);
        String longitudeStr = String.valueOf(longitude);
        String comments = getIntent().getStringExtra("charger_comments");
        String address= getIntent().getStringExtra("charger_address");
        String points = getIntent().getStringExtra("charger_points");
        String cost = getIntent().getStringExtra("charger_cost");

        RequestQueue queue = Volley.newRequestQueue(this);

        
        /*Gets the width of the phone screen so that the size of the image is always set to a max, the code will adjust the
        image accordingly*/
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        int screenWidth = displayMetrics.widthPixels;

        String SVurl = "https://maps.googleapis.com/maps/api/streetview?size=" + screenWidth + "x350"
                + "&location=" + latitude + "," + longitude
                + "&fov=80&heading=70&pitch=10&key=AIzaSyDvOghyeEGi2x2tQ16hptN5V6FA9rMrrLU";

        //Gets the request and uses volley to process request and extract data
        ImageRequest imageRequest = new ImageRequest(SVurl,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap response) {
                        // Handle the Bitmap, e.g., display it in an ImageView
                        ImageView imageView = findViewById(R.id.evStationImage);
                        imageView.setImageBitmap(response);
                    }
                }, 0, 0, ImageView.ScaleType.CENTER_CROP, Bitmap.Config.RGB_565,
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle error
                        Log.e("VolleyError", error.toString());
                    }
                });
        queue.add(imageRequest);

        //Changes appropriate views accordingly
        TextView titleId = findViewById(R.id.titleText);
        TextView contents = findViewById(R.id.contentDescription);
        String formattedContents = String.format("Description: %s \n\n Latitude and Longitude: %s, %s \n\n" + "Address: %s \n\n Number of points: %s \n\n Cost: %s",
                comments, latitudeStr, longitudeStr, address, points, cost);
        titleId.setText(title);
        contents.setText(formattedContents);


    }
}